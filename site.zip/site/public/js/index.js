'use strict';

import App from './App.js';

ReactDOM.render(React.createElement(App, null), document.getElementById('root'));