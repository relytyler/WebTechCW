'use strict';

import Title from './Title.js';
import LikeButton from './like_button.js';

function App() {
    return (
        <div className="App">
            <Title />
        </div> 
    );    
}

export default App;