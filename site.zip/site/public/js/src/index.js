'use strict';
import App from './App.js';

ReactDOM.render(
    <App />,
    document.getElementById('root')
  );